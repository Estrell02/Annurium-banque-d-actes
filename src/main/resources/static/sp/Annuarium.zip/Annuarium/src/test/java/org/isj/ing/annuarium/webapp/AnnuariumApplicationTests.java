package org.isj.ing.annuarium.webapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnnuariumApplicationTests {

	@Test
	void contextLoads() {
	}

}
